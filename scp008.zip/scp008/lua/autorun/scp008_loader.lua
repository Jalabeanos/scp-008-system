SCP008 = SCP008 or {}

if SERVER then
    AddCSLuaFile("scp008/sh_config.lua")
    AddCSLuaFile("scp008/cl_scp008.lua")

    include("scp008/sh_config.lua")
    include("scp008/sv_scp008.lua")
else
    include("scp008/sh_config.lua")
    include("scp008/cl_scp008.lua")
end
