AddCSLuaFile()

SWEP.PrintName = "SCP-008-2"
SWEP.Author = "EternalSnooz"
SWEP.Category = "SCP-008"
SWEP.Instructions = "Left click to claw. Anyone you hit becomes infected."
SWEP.Spawnable = true
SWEP.AdminOnly = true

SWEP.ViewModel = "models/weapons/c_arms.mdl"
SWEP.WorldModel = ""
SWEP.ViewModelFOV = 54
SWEP.UseHands = true

SWEP.Slot = 0
SWEP.SlotPos = 1
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = true

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.HitDistance = 70
SWEP.AttackDelay = 0.8

function SWEP:Initialize()
    self:SetHoldType("fist")
end

function SWEP:PlayAnim(name)
    local owner = self:GetOwner()
    if not IsValid(owner) then return end

    local vm = owner:GetViewModel()
    if not IsValid(vm) then return end

    local seq = vm:LookupSequence(name)
    if seq and seq >= 0 then
        vm:SendViewModelMatchingSequence(seq)
    end
end

function SWEP:Deploy()
    self:PlayAnim("fists_draw")
    self.IdleAt = CurTime() + 0.5
    return true
end

function SWEP:Think()
    if self.IdleAt and CurTime() >= self.IdleAt then
        self.IdleAt = nil
        self:PlayAnim("fists_idle_01")
    end
end

function SWEP:PrimaryAttack()
    local owner = self:GetOwner()
    if not IsValid(owner) then return end

    self:SetNextPrimaryFire(CurTime() + self.AttackDelay)
    self:SetNextSecondaryFire(CurTime() + self.AttackDelay)

    owner:SetAnimation(PLAYER_ATTACK1)
    self.RightHand = not self.RightHand
    self:PlayAnim(self.RightHand and "fists_right" or "fists_left")
    self.IdleAt = CurTime() + 0.6

    if CLIENT then return end

    owner:LagCompensation(true)
    local start = owner:GetShootPos()
    local tr = util.TraceHull({
        start = start,
        endpos = start + owner:GetAimVector() * self.HitDistance,
        filter = owner,
        mins = Vector(-10, -10, -8),
        maxs = Vector(10, 10, 8),
        mask = MASK_SHOT_HULL,
    })
    owner:LagCompensation(false)

    if not tr.Hit then
        owner:EmitSound("npc/zombie/claw_miss" .. math.random(1, 2) .. ".wav", 70)
        return
    end

    owner:EmitSound("npc/zombie/claw_strike" .. math.random(1, 3) .. ".wav", 70)

    local ent = tr.Entity
    if not IsValid(ent) then return end

    local isPlayer = ent:IsPlayer()
    local hasAddon = SCP008 ~= nil

    -- Fellow zombies aren't hurt
    if isPlayer and hasAddon and SCP008.IsZombie(ent) then return end

    local dmg = DamageInfo()
    dmg:SetDamage((hasAddon and SCP008.Config.ZombieDamage) or 25)
    dmg:SetAttacker(owner)
    dmg:SetInflictor(self)
    dmg:SetDamageType(DMG_SLASH)
    dmg:SetDamagePosition(tr.HitPos)
    dmg:SetDamageForce(owner:GetAimVector() * 5000)
    ent:TakeDamageInfo(dmg)

    -- Anyone clawed gets infected (silently, with the normal random incubation)
    if isPlayer and hasAddon then
        SCP008.Infect(ent)
    end
end

function SWEP:SecondaryAttack() end
function SWEP:Reload() end

function SWEP:Holster()
    return true
end
