TOOL.Category = "SCP-008"
TOOL.Name = "#tool.scp008_setup.name"

TOOL.ClientConVar = {
    ["mode"] = "zone",
}

TOOL.Information = {
    { name = "left" },
    { name = "right" },
    { name = "reload" },
}

if CLIENT then
    language.Add("tool.scp008_setup.name", "SCP-008 Setup")
    language.Add("tool.scp008_setup.desc", "Define the SCP-008 trigger door and infection zone")
    language.Add("tool.scp008_setup.left", "Zone mode: set first corner. Door mode: add/remove trigger door or entity")
    language.Add("tool.scp008_setup.right", "Zone mode: set opposite corner and save the zone")
    language.Add("tool.scp008_setup.reload", "Zone mode: delete zone you're in/aiming at (or cancel corner). Door mode: remove aimed entity")
end

local function Say(ply, msg)
    if SERVER and IsValid(ply) then
        ply:ChatPrint("[SCP-008] " .. msg)
    end
end

local function ClearCorner(ply)
    ply.SCP008_CornerA = nil
    ply:SetNWBool("SCP008_HasCorner", false)
end

function TOOL:LeftClick(trace)
    if CLIENT then return true end

    local ply = self:GetOwner()
    if not SCP008 or not SCP008.CanEdit(ply) then
        Say(ply, "Superadmin only.")
        return false
    end

    if self:GetClientInfo("mode") == "door" then
        local ent = trace.Entity
        if not IsValid(ent) then
            Say(ply, "Aim at the door, button or entity that triggers SCP-008.")
            return false
        end

        local added, err = SCP008.ToggleTrigger(ent)
        if added == nil then
            Say(ply, err)
            return false
        end

        Say(ply, (added and "Added " or "Removed ") .. ent:GetClass() .. (added and " as a trigger." or " from the triggers."))
        return true
    end

    -- Zone mode: first corner
    ply.SCP008_CornerA = trace.HitPos
    ply:SetNWVector("SCP008_CornerA", trace.HitPos)
    ply:SetNWBool("SCP008_HasCorner", true)
    Say(ply, "First corner set. Right click the opposite corner (other side of the room, at the opposite height).")
    return true
end

function TOOL:RightClick(trace)
    if CLIENT then return true end

    local ply = self:GetOwner()
    if not SCP008 or not SCP008.CanEdit(ply) then
        Say(ply, "Superadmin only.")
        return false
    end

    if self:GetClientInfo("mode") ~= "zone" then
        Say(ply, "Switch to Zone mode to define the infection zone.")
        return false
    end

    if not ply.SCP008_CornerA then
        Say(ply, "Set the first corner with left click first.")
        return false
    end

    SCP008.AddZone(ply.SCP008_CornerA, trace.HitPos)
    ClearCorner(ply)
    Say(ply, "Infection zone saved.")
    return true
end

function TOOL:Reload(trace)
    if CLIENT then return true end

    local ply = self:GetOwner()
    if not SCP008 or not SCP008.CanEdit(ply) then
        Say(ply, "Superadmin only.")
        return false
    end

    if self:GetClientInfo("mode") == "door" then
        local ent = trace.Entity
        if IsValid(ent) and SCP008.RemoveTrigger(ent) then
            Say(ply, "Trigger removed.")
            return true
        end
        Say(ply, "That entity isn't a trigger.")
        return false
    end

    if ply.SCP008_CornerA then
        ClearCorner(ply)
        Say(ply, "Pending corner cancelled.")
        return true
    end

    if SCP008.RemoveZoneAt(ply:GetPos(), trace.HitPos) then
        Say(ply, "Zone removed.")
        return true
    end

    Say(ply, "No zone found where you're standing or aiming.")
    return false
end

function TOOL:Deploy()
    if CLIENT then
        net.Start("SCP008_Request")
        net.SendToServer()
    end
end

if CLIENT then
    function TOOL.BuildCPanel(panel)
        panel:Help("Pick a mode, then use the tool. Red boxes are infection zones, orange outlines are trigger entities.")

        local combo = vgui.Create("DComboBox")
        combo:SetSortItems(false)
        local cv = GetConVar("scp008_setup_mode")
        local cur = cv and cv:GetString() or "zone"
        combo:AddChoice("Infection zone (2 corners)", "zone", cur == "zone")
        combo:AddChoice("Trigger door / button / entity", "door", cur == "door")
        combo.OnSelect = function(_, _, _, data)
            RunConsoleCommand("scp008_setup_mode", data)
        end
        panel:AddItem(combo)

        panel:Help("Zone mode: left click one corner (e.g. floor corner), right click the opposite corner (e.g. ceiling corner on the far side).")
        panel:Help("Door mode: left click the door/button that releases SCP-008. Click again to remove it.")

        panel:Button("Trigger SCP-008 now (test)", "scp008_trigger")
        panel:Button("Print status to chat", "scp008_status")
        panel:Button("Clear all zones", "scp008_clear_zones")
        panel:Button("Clear all trigger entities", "scp008_clear_triggers")

        net.Start("SCP008_Request")
        net.SendToServer()
    end
end
