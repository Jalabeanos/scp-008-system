SCP008.ClientZones = SCP008.ClientZones or {}
SCP008.ClientTriggers = SCP008.ClientTriggers or {}

net.Receive("SCP008_Sync", function()
    local t = net.ReadTable()
    SCP008.ClientZones = t.zones or {}
    SCP008.ClientTriggers = t.triggers or {}
end)

---------------------------------------------------------------------
-- Toolgun preview (only while holding the SCP-008 tool)
---------------------------------------------------------------------
local function HoldingTool()
    local lp = LocalPlayer()
    if not IsValid(lp) then return false end
    local wep = lp:GetActiveWeapon()
    if not IsValid(wep) or wep:GetClass() ~= "gmod_tool" then return false end
    local cv = GetConVar("gmod_toolmode")
    return cv ~= nil and cv:GetString() == "scp008_setup"
end

local zero = Vector(0, 0, 0)
local angZero = Angle(0, 0, 0)

local function DrawZoneBox(mins, maxs, fill, line)
    render.SetColorMaterial()
    render.DrawBox(zero, angZero, mins, maxs, fill)
    render.CullMode(MATERIAL_CULLMODE_CW)
    render.DrawBox(zero, angZero, mins, maxs, fill)
    render.CullMode(MATERIAL_CULLMODE_CCW)
    render.DrawWireframeBox(zero, angZero, mins, maxs, line, true)
end

hook.Add("PostDrawTranslucentRenderables", "SCP008_DrawZones", function(_, skybox)
    if skybox then return end
    if not HoldingTool() then return end

    for _, z in ipairs(SCP008.ClientZones) do
        DrawZoneBox(z.mins, z.maxs, Color(255, 40, 40, 25), Color(255, 60, 60, 255))
    end

    local lp = LocalPlayer()
    if lp:GetNWBool("SCP008_HasCorner") then
        local a = lp:GetNWVector("SCP008_CornerA")
        local b = lp:GetEyeTrace().HitPos
        local mins, maxs = Vector(a.x, a.y, a.z), Vector(b.x, b.y, b.z)
        OrderVectors(mins, maxs)
        DrawZoneBox(mins, maxs, Color(255, 220, 0, 20), Color(255, 220, 0, 255))
    end
end)

hook.Add("PreDrawHalos", "SCP008_DrawTriggers", function()
    if not HoldingTool() then return end

    local list = {}
    for _, idx in ipairs(SCP008.ClientTriggers) do
        local ent = Entity(idx)
        if IsValid(ent) then list[#list + 1] = ent end
    end

    if #list > 0 then
        halo.Add(list, Color(255, 140, 0), 3, 3, 2, true, true)
    end
end)

---------------------------------------------------------------------
-- Symptom screen effects
---------------------------------------------------------------------
hook.Add("RenderScreenspaceEffects", "SCP008_Sick", function()
    local lp = LocalPlayer()
    if not IsValid(lp) or not lp:Alive() or not lp:GetNWBool("SCP008_Sick") then return end

    local ramp = math.Clamp((CurTime() - lp:GetNWFloat("SCP008_SickStart")) / SCP008.Config.EffectRampTime, 0, 1)

    DrawColorModify({
        ["$pp_colour_addr"] = 0.08 * ramp,
        ["$pp_colour_addg"] = 0,
        ["$pp_colour_addb"] = 0,
        ["$pp_colour_brightness"] = -0.05 * ramp,
        ["$pp_colour_contrast"] = 1,
        ["$pp_colour_colour"] = 1 - 0.6 * ramp,
        ["$pp_colour_mulr"] = 0,
        ["$pp_colour_mulg"] = 0,
        ["$pp_colour_mulb"] = 0,
    })

    if ramp > 0.05 then
        DrawMotionBlur(0.2, 0.5 * ramp, 0.01)
    end
end)
