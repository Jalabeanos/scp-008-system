util.AddNetworkString("SCP008_Sync")
util.AddNetworkString("SCP008_Request")

local CFG = SCP008.Config

SCP008.Zones = SCP008.Zones or {}          -- { {mins = Vector, maxs = Vector}, ... }
SCP008.Triggers = SCP008.Triggers or {}    -- [mapCreationID] = true
SCP008.TriggerEnts = SCP008.TriggerEnts or {}

local DATA_DIR = "scp008"

---------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------
local function SavePath()
    return DATA_DIR .. "/" .. game.GetMap() .. ".json"
end

local function Notify(ply, msg)
    if not IsValid(ply) or not msg or msg == "" then return end
    if DarkRP and DarkRP.notify then
        DarkRP.notify(ply, 1, 8, msg)
    else
        ply:ChatPrint(msg)
    end
end

local function Reply(ply, msg)
    if IsValid(ply) then
        ply:ChatPrint("[SCP-008] " .. msg)
    else
        print("[SCP-008] " .. msg)
    end
end

local function FindPlayer(name)
    name = string.lower(name or "")
    if name == "" then return nil end
    for _, p in ipairs(player.GetAll()) do
        if string.find(string.lower(p:Nick()), name, 1, true) then return p end
    end
end

local BUTTON_CLASSES = {
    func_button = true,
    func_rot_button = true,
    momentary_rot_button = true,
    gmod_button = true,
}

-- Returns true/false (open/closed) for anything that behaves like a door,
-- nil for buttons and other things that have no open/closed state
local function DoorState(ent)
    local class = ent:GetClass()
    if BUTTON_CLASSES[class] then return nil end

    if class == "prop_door_rotating" then
        local s = ent:GetInternalVariable("m_eDoorState")
        if s ~= nil then return s == 1 or s == 2 end -- opening / open
    elseif class == "func_door" or class == "func_door_rotating" then
        local s = ent:GetInternalVariable("m_toggle_state")
        if s ~= nil then return s == 0 or s == 2 end -- at top / going up
    end

    -- Fallback for any other entity: it counts as open while it has moved
    -- away from the position it had when it was registered
    local bp, ba = ent.SCP008_BasePos, ent.SCP008_BaseAng
    if bp and ba then
        local ang = ent:GetAngles()
        return ent:GetPos():DistToSqr(bp) > 4
            or math.abs(math.AngleDifference(ang.p, ba.p)) > 1
            or math.abs(math.AngleDifference(ang.y, ba.y)) > 1
            or math.abs(math.AngleDifference(ang.r, ba.r)) > 1
    end

    return nil
end

---------------------------------------------------------------------
-- Save / load
---------------------------------------------------------------------
function SCP008.Save()
    file.CreateDir(DATA_DIR)
    local out = { zones = {}, triggers = {} }
    for _, z in ipairs(SCP008.Zones) do
        out.zones[#out.zones + 1] = { z.mins.x, z.mins.y, z.mins.z, z.maxs.x, z.maxs.y, z.maxs.z }
    end
    for id in pairs(SCP008.Triggers) do
        out.triggers[#out.triggers + 1] = id
    end
    file.Write(SavePath(), util.TableToJSON(out, true))
end

function SCP008.Load()
    SCP008.Zones, SCP008.Triggers = {}, {}
    if not file.Exists(SavePath(), "DATA") then return end

    local t = util.JSONToTable(file.Read(SavePath(), "DATA") or "")
    if not t then return end

    for _, z in ipairs(t.zones or {}) do
        SCP008.Zones[#SCP008.Zones + 1] = {
            mins = Vector(z[1], z[2], z[3]),
            maxs = Vector(z[4], z[5], z[6]),
        }
    end
    for _, id in ipairs(t.triggers or {}) do
        SCP008.Triggers[id] = true
    end
end

function SCP008.CacheTriggers()
    for _, ent in ipairs(SCP008.TriggerEnts) do
        if IsValid(ent) then ent.SCP008_IsTrigger = nil end
    end

    SCP008.TriggerEnts = {}
    for id in pairs(SCP008.Triggers) do
        local ent = ents.GetMapCreatedEntity(id)
        if IsValid(ent) then
            ent.SCP008_IsTrigger = true
            if not ent.SCP008_BasePos then
                ent.SCP008_BasePos = ent:GetPos()
                ent.SCP008_BaseAng = ent:GetAngles()
            end
            SCP008.TriggerEnts[#SCP008.TriggerEnts + 1] = ent
        end
    end
end

---------------------------------------------------------------------
-- Syncing the setup to editors (for the toolgun preview)
---------------------------------------------------------------------
function SCP008.Sync(ply)
    local trig = {}
    for _, ent in ipairs(SCP008.TriggerEnts) do
        if IsValid(ent) then trig[#trig + 1] = ent:EntIndex() end
    end

    net.Start("SCP008_Sync")
    net.WriteTable({ zones = SCP008.Zones, triggers = trig })
    net.Send(ply)
end

function SCP008.SyncEditors()
    for _, p in ipairs(player.GetAll()) do
        if SCP008.CanEdit(p) then SCP008.Sync(p) end
    end
end

net.Receive("SCP008_Request", function(_, ply)
    if SCP008.CanEdit(ply) then SCP008.Sync(ply) end
end)

---------------------------------------------------------------------
-- Editing (used by the toolgun and the console commands)
---------------------------------------------------------------------
function SCP008.AddZone(a, b)
    local mins, maxs = Vector(a.x, a.y, a.z), Vector(b.x, b.y, b.z)
    OrderVectors(mins, maxs)
    local pad = Vector(CFG.ZonePadding, CFG.ZonePadding, CFG.ZonePadding)
    mins = mins - pad
    maxs = maxs + pad

    SCP008.Zones[#SCP008.Zones + 1] = { mins = mins, maxs = maxs }
    SCP008.Save()
    SCP008.SyncEditors()
end

-- Removes the first zone that contains (or is within 16 units of) any of the given positions
function SCP008.RemoveZoneAt(...)
    local tol = Vector(16, 16, 16)
    for _, pos in ipairs({ ... }) do
        for i, z in ipairs(SCP008.Zones) do
            if pos:WithinAABox(z.mins - tol, z.maxs + tol) then
                table.remove(SCP008.Zones, i)
                SCP008.Save()
                SCP008.SyncEditors()
                return true
            end
        end
    end
    return false
end

-- Returns true if added, false if removed, nil + error if it can't be used
function SCP008.ToggleTrigger(ent)
    local id = ent:MapCreationID()
    if not id or id == -1 then
        return nil, "That entity was not created by the map, so it can't be saved as a trigger."
    end

    local added
    if SCP008.Triggers[id] then
        SCP008.Triggers[id] = nil
        added = false
    else
        SCP008.Triggers[id] = true
        added = true
    end

    SCP008.Save()
    SCP008.CacheTriggers()
    SCP008.SyncEditors()
    return added
end

function SCP008.RemoveTrigger(ent)
    local id = ent:MapCreationID()
    if not id or not SCP008.Triggers[id] then return false end
    SCP008.Triggers[id] = nil
    SCP008.Save()
    SCP008.CacheTriggers()
    SCP008.SyncEditors()
    return true
end

---------------------------------------------------------------------
-- Infection
---------------------------------------------------------------------
function SCP008.IsImmune(ply)
    if CFG.ImmuneJobs[team.GetName(ply:Team())] then return true end
    return CFG.IsImmune(ply) and true or false
end

function SCP008.InZone(ply)
    local p1 = ply:GetPos()
    local p2 = ply:WorldSpaceCenter()
    for _, z in ipairs(SCP008.Zones) do
        if p1:WithinAABox(z.mins, z.maxs) or p2:WithinAABox(z.mins, z.maxs) then
            return true
        end
    end
    return false
end

-- Secretly infects a player. Symptoms start after `delay` seconds (random if not given).
function SCP008.Infect(ply, delay)
    if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return false end
    if ply.SCP008 then return false end
    if ply.SCP008_ImmuneUntil and CurTime() < ply.SCP008_ImmuneUntil then return false end
    if SCP008.IsImmune(ply) then return false end

    ply.SCP008 = {
        onset = CurTime() + (delay or math.Rand(CFG.IncubationMin, CFG.IncubationMax)),
        sick = false,
    }
    return true
end

function SCP008.IsZombie(ply)
    return IsValid(ply) and ply:IsPlayer() and ply.SCP008 ~= nil and ply.SCP008.zombie == true
end

-- Final stage: new playermodel, only the claw SWEP, 500-800 health
function SCP008.Zombify(ply)
    local inf = ply.SCP008
    if not inf or inf.zombie then return end

    inf.zombie = true
    inf.oldModel = ply:GetModel()
    inf.oldMaxHealth = ply:GetMaxHealth()
    inf.oldWeapons = {}
    for _, wep in ipairs(ply:GetWeapons()) do
        inf.oldWeapons[#inf.oldWeapons + 1] = wep:GetClass()
    end

    ply:SetNWBool("SCP008_Sick", false)
    ply:SetNWBool("SCP008_Zombie", true)

    ply:StripWeapons()
    ply:Give(CFG.ZombieWeapon)
    ply:SelectWeapon(CFG.ZombieWeapon)

    ply:SetModel(CFG.ZombieModel)

    local hp = math.random(CFG.ZombieHealthMin, CFG.ZombieHealthMax)
    ply:SetMaxHealth(hp)
    ply:SetHealth(hp)

    if CFG.ZombieTransformSound and CFG.ZombieTransformSound ~= "" then
        ply:EmitSound(CFG.ZombieTransformSound, 80)
    end
    Notify(ply, CFG.ZombifyMessage)
end

-- Puts a zombie back to normal. `alive` = also restore model and weapons.
local function Unzombify(ply, alive)
    local inf = ply.SCP008
    if not inf or not inf.zombie then return end

    ply:SetNWBool("SCP008_Zombie", false)

    if inf.oldMaxHealth then
        ply:SetMaxHealth(inf.oldMaxHealth)
    end

    if alive then
        ply:SetHealth(math.min(ply:Health(), ply:GetMaxHealth()))
        if inf.oldModel then ply:SetModel(inf.oldModel) end

        ply:StripWeapons()
        for _, class in ipairs(inf.oldWeapons or {}) do
            ply:Give(class)
        end
    end
end

-- immuneFor (optional): seconds the player can't be re-infected after the cure
function SCP008.Cure(ply, immuneFor)
    if not IsValid(ply) then return end
    Unzombify(ply, ply:Alive())
    ply.SCP008 = nil
    ply:SetNWBool("SCP008_Sick", false)
    if immuneFor and immuneFor > 0 then
        ply.SCP008_ImmuneUntil = CurTime() + immuneFor
    end
end

---------------------------------------------------------------------
-- Active state: SCP-008 is "released" while a trigger door is open
---------------------------------------------------------------------
SCP008.ActiveUntil = SCP008.ActiveUntil or 0

function SCP008.IsActive()
    -- Timed activation (buttons, manual test)
    if CurTime() < SCP008.ActiveUntil then return true end

    -- Doors: active for as long as any trigger door is open
    for _, ent in ipairs(SCP008.TriggerEnts) do
        if IsValid(ent) and DoorState(ent) == true then return true end
    end

    return false
end

-- Infects everyone currently inside a zone (only does anything while active)
function SCP008.Scan()
    if #SCP008.Zones == 0 or not SCP008.IsActive() then return end

    local count = 0
    for _, ply in ipairs(player.GetAll()) do
        if SCP008.InZone(ply) and SCP008.Infect(ply) then
            count = count + 1
        end
    end

    if count > 0 then
        ServerLog("[SCP-008] " .. count .. " player(s) exposed.\n")
        if CFG.NotifyAdmins then
            for _, p in ipairs(player.GetAll()) do
                if SCP008.CanEdit(p) then
                    p:ChatPrint("[SCP-008] " .. count .. " player(s) exposed.")
                end
            end
        end
    end
end

-- Timed activation for buttons / manual test
function SCP008.Activate(source, duration)
    SCP008.ActiveUntil = math.max(SCP008.ActiveUntil, CurTime() + (duration or CFG.ButtonActiveTime))
    local src = IsValid(source) and source:GetClass() or tostring(source)
    ServerLog("[SCP-008] Activated by " .. src .. ".\n")
    SCP008.Scan()
end

---------------------------------------------------------------------
-- Buttons and other entities with no open/closed state
---------------------------------------------------------------------
hook.Add("PlayerUse", "SCP008_Use", function(ply, ent)
    if IsValid(ent) and ent.SCP008_IsTrigger and DoorState(ent) == nil then
        SCP008.Activate(ent)
    end
end)

local TRIGGER_INPUTS = { open = true, toggle = true, press = true, use = true, trigger = true, pressin = true }

hook.Add("AcceptInput", "SCP008_Input", function(ent, input)
    if IsValid(ent) and ent.SCP008_IsTrigger and TRIGGER_INPUTS[string.lower(input)] and DoorState(ent) == nil then
        SCP008.Activate(ent)
    end
end)

---------------------------------------------------------------------
-- Infection progression
---------------------------------------------------------------------
timer.Create("SCP008_Process", 0.25, 0, function()
    local now = CurTime()

    -- While the door is open, anyone inside (or walking into) a zone gets exposed
    SCP008.Scan()

    for _, ply in ipairs(player.GetAll()) do
        local inf = ply.SCP008
        if inf then
            if not ply:Alive() then
                SCP008.Cure(ply)
            elseif inf.zombie then
                -- Keep the zombie model on (DarkRP can reset models on job changes etc.)
                if string.lower(ply:GetModel()) ~= string.lower(CFG.ZombieModel) then
                    ply:SetModel(CFG.ZombieModel)
                end
            elseif not inf.sick then
                if now >= inf.onset then
                    inf.sick = true
                    inf.nextDamage = now + CFG.DamageInterval
                    inf.nextCough = now + math.Rand(2, 5)
                    inf.zombifyAt = now + math.Rand(CFG.ZombifyMin, CFG.ZombifyMax)
                    ply:SetNWFloat("SCP008_SickStart", now)
                    ply:SetNWBool("SCP008_Sick", true)
                    Notify(ply, CFG.OnsetMessage)
                end
            elseif now >= inf.zombifyAt then
                SCP008.Zombify(ply)
            else
                if now >= inf.nextCough then
                    inf.nextCough = now + math.Rand(CFG.CoughMin, CFG.CoughMax)
                    local snd = CFG.CoughSounds[math.random(#CFG.CoughSounds)]
                    if snd then ply:EmitSound(snd, 70) end
                    ply:ViewPunch(Angle(math.Rand(2, 5), math.Rand(-2, 2), 0))
                end

                if now >= inf.nextDamage then
                    inf.nextDamage = now + CFG.DamageInterval
                    -- Symptoms wear them down but never kill them before they turn
                    if ply:Health() - CFG.DamagePerTick > CFG.SymptomMinHealth then
                        local dmg = DamageInfo()
                        dmg:SetDamage(CFG.DamagePerTick)
                        dmg:SetAttacker(game.GetWorld())
                        dmg:SetInflictor(game.GetWorld())
                        dmg:SetDamageType(DMG_POISON)
                        ply:TakeDamageInfo(dmg)
                    end
                end
            end
        end
    end
end)

hook.Add("PlayerDeath", "SCP008_Death", function(victim)
    local inf = victim.SCP008
    if inf and inf.sick and not inf.zombie and CFG.SpawnZombie then
        local pos = victim:GetPos()
        timer.Simple(0.1, function()
            local z = ents.Create(CFG.ZombieClass)
            if not IsValid(z) then return end
            z:SetPos(pos + Vector(0, 0, 10))
            z:SetAngles(Angle(0, math.random(0, 359), 0))
            z:Spawn()
            z:Activate()
            if CFG.ZombieLifetime > 0 then
                SafeRemoveEntityDelayed(z, CFG.ZombieLifetime)
            end
        end)
    end
    SCP008.Cure(victim)
end)

hook.Add("PlayerSpawn", "SCP008_Spawn", function(ply)
    SCP008.Cure(ply)
    ply.SCP008_ImmuneUntil = nil
end)

---------------------------------------------------------------------
-- Zombie restrictions
---------------------------------------------------------------------
-- Zombies can only hold the claw SWEP
hook.Add("PlayerCanPickupWeapon", "SCP008_ZombieWeapons", function(ply, wep)
    if SCP008.IsZombie(ply) and wep:GetClass() ~= CFG.ZombieWeapon then
        return false
    end
end)

-- If a job loadout runs while they're a zombie, give only the claws
hook.Add("PlayerLoadout", "SCP008_ZombieLoadout", function(ply)
    if SCP008.IsZombie(ply) then
        ply:Give(CFG.ZombieWeapon)
        return true
    end
end)

-- DarkRP: no dropping the claws, no changing job to escape the transformation
hook.Add("canDropWeapon", "SCP008_ZombieNoDrop", function(ply, wep)
    if SCP008.IsZombie(ply) then return false end
end)

hook.Add("playerCanChangeTeam", "SCP008_ZombieNoJobChange", function(ply)
    if SCP008.IsZombie(ply) then
        return false, "You can't change jobs while you're infected."
    end
end)

---------------------------------------------------------------------
-- Map load
---------------------------------------------------------------------
hook.Add("InitPostEntity", "SCP008_Init", function()
    SCP008.Load()
    SCP008.CacheTriggers()
end)

hook.Add("PostCleanupMap", "SCP008_Cleanup", function()
    SCP008.CacheTriggers()
end)

-- Support for reloading the file while the server is running
if player.GetCount() > 0 or SCP008.Loaded then
    SCP008.Load()
    SCP008.CacheTriggers()
end
SCP008.Loaded = true

---------------------------------------------------------------------
-- Console commands (superadmin or server console)
---------------------------------------------------------------------
local function CanUse(ply)
    return not IsValid(ply) or SCP008.CanEdit(ply)
end

concommand.Add("scp008_trigger", function(ply)
    if not CanUse(ply) then return end
    SCP008.Activate("manual", CFG.ManualActiveTime)
    Reply(ply, "SCP-008 released for " .. CFG.ManualActiveTime .. " seconds.")
end)

-- scp008_infect "<name>" [seconds until symptoms]
concommand.Add("scp008_infect", function(ply, _, args)
    if not CanUse(ply) then return end
    local target = FindPlayer(args[1])
    if not target then return Reply(ply, "Player not found.") end
    local delay = tonumber(args[2])
    if SCP008.Infect(target, delay) then
        Reply(ply, target:Nick() .. " infected" .. (delay and (" (symptoms in " .. delay .. "s)") or "") .. ".")
    else
        Reply(ply, "Couldn't infect " .. target:Nick() .. " (dead, immune or already infected).")
    end
end)

concommand.Add("scp008_cure", function(ply, _, args)
    if not CanUse(ply) then return end
    local target = FindPlayer(args[1])
    if not target then return Reply(ply, "Player not found.") end
    SCP008.Cure(target)
    Reply(ply, target:Nick() .. " cured.")
end)

concommand.Add("scp008_status", function(ply)
    if not CanUse(ply) then return end
    Reply(ply, #SCP008.Zones .. " zone(s), " .. #SCP008.TriggerEnts .. " trigger entity(ies).")
    for _, p in ipairs(player.GetAll()) do
        local inf = p.SCP008
        if inf then
            if inf.zombie then
                Reply(ply, p:Nick() .. " - zombie")
            elseif inf.sick then
                Reply(ply, p:Nick() .. " - symptomatic, turns in " .. math.max(0, math.floor(inf.zombifyAt - CurTime())) .. "s")
            else
                Reply(ply, p:Nick() .. " - incubating, symptoms in " .. math.max(0, math.floor(inf.onset - CurTime())) .. "s")
            end
        end
    end
end)

concommand.Add("scp008_clear_zones", function(ply)
    if not CanUse(ply) then return end
    SCP008.Zones = {}
    SCP008.Save()
    SCP008.SyncEditors()
    Reply(ply, "All zones cleared.")
end)

concommand.Add("scp008_clear_triggers", function(ply)
    if not CanUse(ply) then return end
    SCP008.Triggers = {}
    SCP008.Save()
    SCP008.CacheTriggers()
    SCP008.SyncEditors()
    Reply(ply, "All trigger entities cleared.")
end)
