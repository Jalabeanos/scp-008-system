AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"

ENT.PrintName = "SCP-500"
ENT.Author = "EternalSnooz"
ENT.Category = "SCP-008"
ENT.Spawnable = true
ENT.AdminOnly = true

-- Change these if you have a custom pill model / sounds
ENT.PillModel = "models/props_lab/jar01a.mdl"
ENT.EatSound = "npc/barnacle/barnacle_gulp1.wav"
ENT.HealSound = "items/smallmedkit1.wav"

function ENT:Initialize()
    if SERVER then
        self:SetModel(self.PillModel)
        self:PhysicsInit(SOLID_VPHYSICS)
        self:SetMoveType(MOVETYPE_VPHYSICS)
        self:SetSolid(SOLID_VPHYSICS)
        self:SetUseType(SIMPLE_USE)

        local phys = self:GetPhysicsObject()
        if IsValid(phys) then phys:Wake() end
    end
end

if SERVER then
    function ENT:SpawnFunction(ply, tr, class)
        if not tr.Hit then return end
        local ent = ents.Create(class)
        ent:SetPos(tr.HitPos + tr.HitNormal * 16)
        ent:Spawn()
        ent:Activate()
        return ent
    end

    function ENT:Use(activator)
        if self.Used then return end
        if not IsValid(activator) or not activator:IsPlayer() or not activator:Alive() then return end

        self.Used = true

        -- Cure SCP-008 (if the addon is loaded) and give a short re-infection immunity
        if SCP008 and SCP008.Cure then
            local immunity = SCP008.Config and SCP008.Config.Scp500Immunity or 0
            SCP008.Cure(activator, immunity)
        end

        -- Full heal
        activator:SetHealth(activator:GetMaxHealth())

        local healSound = self.HealSound
        activator:EmitSound(self.EatSound)
        timer.Simple(0.4, function()
            if IsValid(activator) then activator:EmitSound(healSound) end
        end)

        if DarkRP and DarkRP.notify then
            DarkRP.notify(activator, 0, 6, "You swallowed an SCP-500 pill. Any infection is gone and your health is fully restored.")
        else
            activator:ChatPrint("You swallowed an SCP-500 pill. Any infection is gone and your health is fully restored.")
        end

        self:Remove()
    end
end

if CLIENT then
    function ENT:Draw()
        self:DrawModel()
    end
end
