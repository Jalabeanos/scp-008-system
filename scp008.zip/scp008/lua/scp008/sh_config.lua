SCP008 = SCP008 or {}

SCP008.Config = {
    -- Who can use the toolgun tool and the admin commands
    CanEdit = function(ply)
        return IsValid(ply) and ply:IsSuperAdmin()
    end,

    -- Random delay (seconds) between being exposed and symptoms starting
    IncubationMin = 30,
    IncubationMax = 300,

    -- Doors: SCP-008 is active for as long as the door is open.
    -- Buttons / other entities have no open state, so they release it for this many seconds per press
    ButtonActiveTime = 30,

    -- How long the admin test command (scp008_trigger) keeps it active
    ManualActiveTime = 30,

    -- Seconds of immunity after being cured by SCP-500 (so you aren't re-infected instantly
    -- while still standing in an open zone). 0 = no immunity.
    Scp500Immunity = 60,

    -- Zones are expanded by this many units on every side when created
    ZonePadding = 4,

    -- Jobs that can never be infected. Use the exact job name, e.g. ["SCP-049"] = true
    ImmuneJobs = {
        -- ["Foundation Medic"] = true,
    },

    -- Extra custom immunity check (e.g. hazmat suit). Return true to make the player immune.
    IsImmune = function(ply)
        return false
    end,

    -- Shown to the player when symptoms begin ("" to disable)
    OnsetMessage = "You start coughing... something is wrong with you.",

    -- Tell admins (CanEdit) in chat how many players were exposed on each trigger
    NotifyAdmins = false,

    -- Symptoms
    DamagePerTick = 2,
    DamageInterval = 2,
    CoughMin = 4,
    CoughMax = 9,
    CoughSounds = {
        "ambient/voices/cough1.wav",
        "ambient/voices/cough2.wav",
        "ambient/voices/cough3.wav",
        "ambient/voices/cough4.wav",
    },

    -- Symptomatic players turn into a zombie this many seconds after symptoms start (random in range)
    ZombifyMin = 90,
    ZombifyMax = 180,

    -- Symptom damage never takes a player below this much health (so they live to turn)
    SymptomMinHealth = 10,

    -- The zombie form
    ZombieModel = "models/player/zombie_classic.mdl",
    ZombieWeapon = "scp_008_2",
    ZombieHealthMin = 500,
    ZombieHealthMax = 800,
    ZombieDamage = 25,                              -- damage per claw hit
    ZombieTransformSound = "npc/zombie/zombie_alert1.wav", -- "" to disable
    ZombifyMessage = "You can't think straight anymore... you feel hunger and rage.",

    -- Player dies while symptomatic but BEFORE turning -> spawn an NPC zombie at their body
    SpawnZombie = false,
    ZombieClass = "npc_zombie",
    ZombieLifetime = 0, -- seconds before the zombie is removed, 0 = never

    -- Seconds for the screen effects to reach full strength after symptoms begin
    EffectRampTime = 60,
}

function SCP008.CanEdit(ply)
    return SCP008.Config.CanEdit(ply)
end
